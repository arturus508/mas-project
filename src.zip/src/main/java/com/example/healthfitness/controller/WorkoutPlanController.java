package com.example.healthfitness.controller;

import com.example.healthfitness.model.Exercise;
import com.example.healthfitness.model.WorkoutPlan;
import com.example.healthfitness.service.WorkoutPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workout-plans")
public class WorkoutPlanController {

    @Autowired
    private WorkoutPlanService workoutPlanService;

    @GetMapping
    public List<WorkoutPlan> getAllWorkoutPlans() {
        return workoutPlanService.getAllWorkoutPlans();
    }

    @PostMapping("/{workoutPlanId}/exercises")
    public Exercise addExerciseToWorkoutPlan(@PathVariable Long workoutPlanId, @RequestBody Exercise exercise) {
        return workoutPlanService.addExerciseToWorkoutPlan(workoutPlanId, exercise);
    }

    @GetMapping("/{workoutPlanId}/exercises")
    public List<Exercise> getExercisesByWorkoutPlan(@PathVariable Long workoutPlanId) {
        return workoutPlanService.getExercisesByWorkoutPlan(workoutPlanId);
    }
}






