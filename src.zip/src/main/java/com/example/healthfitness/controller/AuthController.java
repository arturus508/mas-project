package com.example.healthfitness.controller;

import com.example.healthfitness.model.User;
import com.example.healthfitness.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
public class AuthController {
    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")  // ✅ Now handles /register instead of /auth/register
    public String showRegisterForm() {
        return "register";
    }

    @PostMapping("/register")  // ✅ Now handles POST /register directly
    public String register(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String password,
                           Model model) {
        Optional<User> existingUser = userService.findByEmail(email);
        if (existingUser.isPresent()) {
            model.addAttribute("error", "User already exists!");
            return "register";
        }

        userService.registerUser(name, email, password);
        return "redirect:/login?registered=true";
    }
}







