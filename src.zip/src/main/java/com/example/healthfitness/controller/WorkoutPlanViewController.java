package com.example.healthfitness.controller;

import com.example.healthfitness.service.WorkoutPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WorkoutPlanViewController {

    @Autowired
    private WorkoutPlanService workoutPlanService;

    @GetMapping("/workout-plans")
    public String showWorkoutPlans(Model model) {
        model.addAttribute("workoutPlans", workoutPlanService.getAllWorkoutPlans());
        return "workout-plans";
    }
}




