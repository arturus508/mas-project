package com.example.healthfitness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthFitnessApplication {

    public static void main(String[] args) {
        SpringApplication.run(HealthFitnessApplication.class, args);
    }

}
