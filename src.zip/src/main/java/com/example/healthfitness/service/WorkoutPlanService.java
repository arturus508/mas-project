package com.example.healthfitness.service;

import com.example.healthfitness.model.WorkoutPlan;
import com.example.healthfitness.model.Exercise;
import com.example.healthfitness.repository.WorkoutPlanRepository;
import com.example.healthfitness.repository.ExerciseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkoutPlanService {

    @Autowired
    private WorkoutPlanRepository workoutPlanRepository;

    @Autowired
    private ExerciseRepository exerciseRepository;

    public List<WorkoutPlan> getAllWorkoutPlans() {
        return workoutPlanRepository.findAll();
    }

    public WorkoutPlan createWorkoutPlan(WorkoutPlan workoutPlan) {
        return workoutPlanRepository.save(workoutPlan);
    }

    public Exercise addExerciseToWorkoutPlan(Long workoutPlanId, Exercise exercise) {
        WorkoutPlan workoutPlan = workoutPlanRepository.findById(workoutPlanId)
                .orElseThrow(() -> new RuntimeException("Workout plan not found with ID: " + workoutPlanId));
        exercise.setWorkoutPlan(workoutPlan);
        return exerciseRepository.save(exercise);
    }

    public List<Exercise> getExercisesByWorkoutPlan(Long workoutPlanId) {
        WorkoutPlan workoutPlan = workoutPlanRepository.findById(workoutPlanId)
                .orElseThrow(() -> new RuntimeException("Workout plan not found with ID: " + workoutPlanId));
        return workoutPlan.getExercises();
    }
    public WorkoutPlan saveWorkoutPlan(WorkoutPlan workoutPlan) {
        return workoutPlanRepository.save(workoutPlan);
    }

    public void deleteWorkoutPlan(Long id) {
        workoutPlanRepository.deleteById(id);
    }


}


